--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 14.15 (Ubuntu 14.15-0ubuntu0.22.04.1)
-- Dumped by pg_dump version 14.15 (Ubuntu 14.15-0ubuntu0.22.04.1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE pcdb_test;
--
-- Name: pcdb_test; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE pcdb_test WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE = 'en_US.UTF-8';


ALTER DATABASE pcdb_test OWNER TO postgres;

\connect pcdb_test

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: adapters; Type: TABLE; Schema: public; Owner: testuser
--

CREATE TABLE public.adapters (
    id integer NOT NULL,
    name character varying NOT NULL
);


ALTER TABLE public.adapters OWNER TO testuser;

--
-- Name: adapters_id_seq; Type: SEQUENCE; Schema: public; Owner: testuser
--

CREATE SEQUENCE public.adapters_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.adapters_id_seq OWNER TO testuser;

--
-- Name: adapters_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: testuser
--

ALTER SEQUENCE public.adapters_id_seq OWNED BY public.adapters.id;


--
-- Name: brands; Type: TABLE; Schema: public; Owner: testuser
--

CREATE TABLE public.brands (
    id integer NOT NULL,
    name character varying NOT NULL
);


ALTER TABLE public.brands OWNER TO testuser;

--
-- Name: brands_id_seq; Type: SEQUENCE; Schema: public; Owner: testuser
--

CREATE SEQUENCE public.brands_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.brands_id_seq OWNER TO testuser;

--
-- Name: brands_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: testuser
--

ALTER SEQUENCE public.brands_id_seq OWNED BY public.brands.id;


--
-- Name: builds; Type: TABLE; Schema: public; Owner: testuser
--

CREATE TABLE public.builds (
    id integer NOT NULL,
    processor_id integer NOT NULL,
    graphics_card_id integer NOT NULL,
    motherboard_id integer NOT NULL,
    power_supply_id integer NOT NULL,
    random_access_memory_id integer NOT NULL,
    drive_id integer NOT NULL,
    popularity integer NOT NULL
);


ALTER TABLE public.builds OWNER TO testuser;

--
-- Name: builds_id_seq; Type: SEQUENCE; Schema: public; Owner: testuser
--

CREATE SEQUENCE public.builds_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.builds_id_seq OWNER TO testuser;

--
-- Name: builds_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: testuser
--

ALTER SEQUENCE public.builds_id_seq OWNED BY public.builds.id;


--
-- Name: connection_configurations; Type: TABLE; Schema: public; Owner: testuser
--

CREATE TABLE public.connection_configurations (
    id integer NOT NULL,
    name character varying NOT NULL
);


ALTER TABLE public.connection_configurations OWNER TO testuser;

--
-- Name: connection_configurations_id_seq; Type: SEQUENCE; Schema: public; Owner: testuser
--

CREATE SEQUENCE public.connection_configurations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.connection_configurations_id_seq OWNER TO testuser;

--
-- Name: connection_configurations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: testuser
--

ALTER SEQUENCE public.connection_configurations_id_seq OWNED BY public.connection_configurations.id;


--
-- Name: cpu_series; Type: TABLE; Schema: public; Owner: testuser
--

CREATE TABLE public.cpu_series (
    id integer NOT NULL,
    name character varying NOT NULL
);


ALTER TABLE public.cpu_series OWNER TO testuser;

--
-- Name: cpu_series_id_seq; Type: SEQUENCE; Schema: public; Owner: testuser
--

CREATE SEQUENCE public.cpu_series_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.cpu_series_id_seq OWNER TO testuser;

--
-- Name: cpu_series_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: testuser
--

ALTER SEQUENCE public.cpu_series_id_seq OWNED BY public.cpu_series.id;


--
-- Name: drive_form_factors; Type: TABLE; Schema: public; Owner: testuser
--

CREATE TABLE public.drive_form_factors (
    id integer NOT NULL,
    name character varying NOT NULL
);


ALTER TABLE public.drive_form_factors OWNER TO testuser;

--
-- Name: drive_form_factors_id_seq; Type: SEQUENCE; Schema: public; Owner: testuser
--

CREATE SEQUENCE public.drive_form_factors_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.drive_form_factors_id_seq OWNER TO testuser;

--
-- Name: drive_form_factors_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: testuser
--

ALTER SEQUENCE public.drive_form_factors_id_seq OWNED BY public.drive_form_factors.id;


--
-- Name: drive_series; Type: TABLE; Schema: public; Owner: testuser
--

CREATE TABLE public.drive_series (
    id integer NOT NULL,
    name character varying NOT NULL
);


ALTER TABLE public.drive_series OWNER TO testuser;

--
-- Name: drive_series_id_seq; Type: SEQUENCE; Schema: public; Owner: testuser
--

CREATE SEQUENCE public.drive_series_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.drive_series_id_seq OWNER TO testuser;

--
-- Name: drive_series_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: testuser
--

ALTER SEQUENCE public.drive_series_id_seq OWNED BY public.drive_series.id;


--
-- Name: drive_types; Type: TABLE; Schema: public; Owner: testuser
--

CREATE TABLE public.drive_types (
    id integer NOT NULL,
    name character varying NOT NULL
);


ALTER TABLE public.drive_types OWNER TO testuser;

--
-- Name: drive_types_id_seq; Type: SEQUENCE; Schema: public; Owner: testuser
--

CREATE SEQUENCE public.drive_types_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.drive_types_id_seq OWNER TO testuser;

--
-- Name: drive_types_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: testuser
--

ALTER SEQUENCE public.drive_types_id_seq OWNED BY public.drive_types.id;


--
-- Name: drives; Type: TABLE; Schema: public; Owner: testuser
--

CREATE TABLE public.drives (
    id integer NOT NULL,
    brand_id integer NOT NULL,
    series_id integer NOT NULL,
    drive_type_id integer NOT NULL,
    form_factor_id integer NOT NULL,
    model character varying NOT NULL,
    capacity_gb integer NOT NULL,
    max_read_mb_s integer NOT NULL,
    max_write_mb_s integer NOT NULL,
    interface_id integer NOT NULL,
    image_url character varying NOT NULL
);


ALTER TABLE public.drives OWNER TO testuser;

--
-- Name: drives_id_seq; Type: SEQUENCE; Schema: public; Owner: testuser
--

CREATE SEQUENCE public.drives_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.drives_id_seq OWNER TO testuser;

--
-- Name: drives_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: testuser
--

ALTER SEQUENCE public.drives_id_seq OWNED BY public.drives.id;


--
-- Name: energy_efficiencies; Type: TABLE; Schema: public; Owner: testuser
--

CREATE TABLE public.energy_efficiencies (
    id integer NOT NULL,
    name character varying NOT NULL
);


ALTER TABLE public.energy_efficiencies OWNER TO testuser;

--
-- Name: energy_efficiencies_id_seq; Type: SEQUENCE; Schema: public; Owner: testuser
--

CREATE SEQUENCE public.energy_efficiencies_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.energy_efficiencies_id_seq OWNER TO testuser;

--
-- Name: energy_efficiencies_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: testuser
--

ALTER SEQUENCE public.energy_efficiencies_id_seq OWNED BY public.energy_efficiencies.id;


--
-- Name: gpu_chipset_manufacturers; Type: TABLE; Schema: public; Owner: testuser
--

CREATE TABLE public.gpu_chipset_manufacturers (
    id integer NOT NULL,
    name character varying NOT NULL
);


ALTER TABLE public.gpu_chipset_manufacturers OWNER TO testuser;

--
-- Name: gpu_chipset_manufacturers_id_seq; Type: SEQUENCE; Schema: public; Owner: testuser
--

CREATE SEQUENCE public.gpu_chipset_manufacturers_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.gpu_chipset_manufacturers_id_seq OWNER TO testuser;

--
-- Name: gpu_chipset_manufacturers_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: testuser
--

ALTER SEQUENCE public.gpu_chipset_manufacturers_id_seq OWNED BY public.gpu_chipset_manufacturers.id;


--
-- Name: gpu_memory_types; Type: TABLE; Schema: public; Owner: testuser
--

CREATE TABLE public.gpu_memory_types (
    id integer NOT NULL,
    name character varying NOT NULL
);


ALTER TABLE public.gpu_memory_types OWNER TO testuser;

--
-- Name: gpu_memory_types_id_seq; Type: SEQUENCE; Schema: public; Owner: testuser
--

CREATE SEQUENCE public.gpu_memory_types_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.gpu_memory_types_id_seq OWNER TO testuser;

--
-- Name: gpu_memory_types_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: testuser
--

ALTER SEQUENCE public.gpu_memory_types_id_seq OWNED BY public.gpu_memory_types.id;


--
-- Name: gpu_outputs; Type: TABLE; Schema: public; Owner: testuser
--

CREATE TABLE public.gpu_outputs (
    id integer NOT NULL,
    graphics_card_id integer NOT NULL,
    output_id integer NOT NULL,
    quantity integer NOT NULL
);


ALTER TABLE public.gpu_outputs OWNER TO testuser;

--
-- Name: gpu_outputs_id_seq; Type: SEQUENCE; Schema: public; Owner: testuser
--

CREATE SEQUENCE public.gpu_outputs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.gpu_outputs_id_seq OWNER TO testuser;

--
-- Name: gpu_outputs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: testuser
--

ALTER SEQUENCE public.gpu_outputs_id_seq OWNED BY public.gpu_outputs.id;


--
-- Name: gpu_power_connectors; Type: TABLE; Schema: public; Owner: testuser
--

CREATE TABLE public.gpu_power_connectors (
    id integer NOT NULL,
    graphics_card_id integer NOT NULL,
    power_connector_id integer NOT NULL,
    quantity integer NOT NULL
);


ALTER TABLE public.gpu_power_connectors OWNER TO testuser;

--
-- Name: gpu_power_connectors_id_seq; Type: SEQUENCE; Schema: public; Owner: testuser
--

CREATE SEQUENCE public.gpu_power_connectors_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.gpu_power_connectors_id_seq OWNER TO testuser;

--
-- Name: gpu_power_connectors_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: testuser
--

ALTER SEQUENCE public.gpu_power_connectors_id_seq OWNED BY public.gpu_power_connectors.id;


--
-- Name: graphics_cards; Type: TABLE; Schema: public; Owner: testuser
--

CREATE TABLE public.graphics_cards (
    id integer NOT NULL,
    brand_id integer NOT NULL,
    name character varying NOT NULL,
    model character varying NOT NULL,
    chipset_manufacturer_id integer NOT NULL,
    memory_type_id integer NOT NULL,
    memory_size_gb integer NOT NULL,
    thermal_design_power_w integer NOT NULL,
    slot_width_inches integer NOT NULL,
    interface_id integer NOT NULL,
    image_url character varying NOT NULL
);


ALTER TABLE public.graphics_cards OWNER TO testuser;

--
-- Name: graphics_cards_id_seq; Type: SEQUENCE; Schema: public; Owner: testuser
--

CREATE SEQUENCE public.graphics_cards_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.graphics_cards_id_seq OWNER TO testuser;

--
-- Name: graphics_cards_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: testuser
--

ALTER SEQUENCE public.graphics_cards_id_seq OWNED BY public.graphics_cards.id;


--
-- Name: integrated_graphics; Type: TABLE; Schema: public; Owner: testuser
--

CREATE TABLE public.integrated_graphics (
    id integer NOT NULL,
    name character varying NOT NULL
);


ALTER TABLE public.integrated_graphics OWNER TO testuser;

--
-- Name: integrated_graphics_id_seq; Type: SEQUENCE; Schema: public; Owner: testuser
--

CREATE SEQUENCE public.integrated_graphics_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.integrated_graphics_id_seq OWNER TO testuser;

--
-- Name: integrated_graphics_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: testuser
--

ALTER SEQUENCE public.integrated_graphics_id_seq OWNED BY public.integrated_graphics.id;


--
-- Name: interfaces; Type: TABLE; Schema: public; Owner: testuser
--

CREATE TABLE public.interfaces (
    id integer NOT NULL,
    name character varying NOT NULL,
    version double precision
);


ALTER TABLE public.interfaces OWNER TO testuser;

--
-- Name: interfaces_id_seq; Type: SEQUENCE; Schema: public; Owner: testuser
--

CREATE SEQUENCE public.interfaces_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.interfaces_id_seq OWNER TO testuser;

--
-- Name: interfaces_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: testuser
--

ALTER SEQUENCE public.interfaces_id_seq OWNED BY public.interfaces.id;


--
-- Name: mb_chipset_manufacturers; Type: TABLE; Schema: public; Owner: testuser
--

CREATE TABLE public.mb_chipset_manufacturers (
    id integer NOT NULL,
    name character varying NOT NULL
);


ALTER TABLE public.mb_chipset_manufacturers OWNER TO testuser;

--
-- Name: mb_chipset_manufacturers_id_seq; Type: SEQUENCE; Schema: public; Owner: testuser
--

CREATE SEQUENCE public.mb_chipset_manufacturers_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.mb_chipset_manufacturers_id_seq OWNER TO testuser;

--
-- Name: mb_chipset_manufacturers_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: testuser
--

ALTER SEQUENCE public.mb_chipset_manufacturers_id_seq OWNED BY public.mb_chipset_manufacturers.id;


--
-- Name: mb_chipsets; Type: TABLE; Schema: public; Owner: testuser
--

CREATE TABLE public.mb_chipsets (
    id integer NOT NULL,
    name character varying NOT NULL,
    manufacturer_id integer NOT NULL
);


ALTER TABLE public.mb_chipsets OWNER TO testuser;

--
-- Name: mb_chipsets_id_seq; Type: SEQUENCE; Schema: public; Owner: testuser
--

CREATE SEQUENCE public.mb_chipsets_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.mb_chipsets_id_seq OWNER TO testuser;

--
-- Name: mb_chipsets_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: testuser
--

ALTER SEQUENCE public.mb_chipsets_id_seq OWNED BY public.mb_chipsets.id;


--
-- Name: mb_form_factors; Type: TABLE; Schema: public; Owner: testuser
--

CREATE TABLE public.mb_form_factors (
    id integer NOT NULL,
    name character varying NOT NULL
);


ALTER TABLE public.mb_form_factors OWNER TO testuser;

--
-- Name: mb_form_factors_id_seq; Type: SEQUENCE; Schema: public; Owner: testuser
--

CREATE SEQUENCE public.mb_form_factors_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.mb_form_factors_id_seq OWNER TO testuser;

--
-- Name: mb_form_factors_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: testuser
--

ALTER SEQUENCE public.mb_form_factors_id_seq OWNED BY public.mb_form_factors.id;


--
-- Name: mb_interfaces; Type: TABLE; Schema: public; Owner: testuser
--

CREATE TABLE public.mb_interfaces (
    id integer NOT NULL,
    motherboard_id integer NOT NULL,
    interface_id integer NOT NULL,
    quantity integer NOT NULL,
    type character varying NOT NULL
);


ALTER TABLE public.mb_interfaces OWNER TO testuser;

--
-- Name: mb_interfaces_id_seq; Type: SEQUENCE; Schema: public; Owner: testuser
--

CREATE SEQUENCE public.mb_interfaces_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.mb_interfaces_id_seq OWNER TO testuser;

--
-- Name: mb_interfaces_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: testuser
--

ALTER SEQUENCE public.mb_interfaces_id_seq OWNED BY public.mb_interfaces.id;


--
-- Name: mb_outputs; Type: TABLE; Schema: public; Owner: testuser
--

CREATE TABLE public.mb_outputs (
    id integer NOT NULL,
    motherboard_id integer NOT NULL,
    output_id integer NOT NULL,
    quantity integer NOT NULL
);


ALTER TABLE public.mb_outputs OWNER TO testuser;

--
-- Name: mb_outputs_id_seq; Type: SEQUENCE; Schema: public; Owner: testuser
--

CREATE SEQUENCE public.mb_outputs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.mb_outputs_id_seq OWNER TO testuser;

--
-- Name: mb_outputs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: testuser
--

ALTER SEQUENCE public.mb_outputs_id_seq OWNED BY public.mb_outputs.id;


--
-- Name: modularity; Type: TABLE; Schema: public; Owner: testuser
--

CREATE TABLE public.modularity (
    id integer NOT NULL,
    name character varying NOT NULL
);


ALTER TABLE public.modularity OWNER TO testuser;

--
-- Name: modularity_id_seq; Type: SEQUENCE; Schema: public; Owner: testuser
--

CREATE SEQUENCE public.modularity_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.modularity_id_seq OWNER TO testuser;

--
-- Name: modularity_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: testuser
--

ALTER SEQUENCE public.modularity_id_seq OWNED BY public.modularity.id;


--
-- Name: motherboards; Type: TABLE; Schema: public; Owner: testuser
--

CREATE TABLE public.motherboards (
    id integer NOT NULL,
    brand_id integer NOT NULL,
    model character varying NOT NULL,
    socket_id integer NOT NULL,
    chipset_id integer NOT NULL,
    form_factor_id integer NOT NULL,
    memory_type_id integer NOT NULL,
    max_memory_supported_gb integer NOT NULL,
    memory_slots integer NOT NULL,
    image_url character varying NOT NULL
);


ALTER TABLE public.motherboards OWNER TO testuser;

--
-- Name: motherboards_id_seq; Type: SEQUENCE; Schema: public; Owner: testuser
--

CREATE SEQUENCE public.motherboards_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.motherboards_id_seq OWNER TO testuser;

--
-- Name: motherboards_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: testuser
--

ALTER SEQUENCE public.motherboards_id_seq OWNED BY public.motherboards.id;


--
-- Name: outputs; Type: TABLE; Schema: public; Owner: testuser
--

CREATE TABLE public.outputs (
    id integer NOT NULL,
    name character varying NOT NULL
);


ALTER TABLE public.outputs OWNER TO testuser;

--
-- Name: outputs_id_seq; Type: SEQUENCE; Schema: public; Owner: testuser
--

CREATE SEQUENCE public.outputs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.outputs_id_seq OWNER TO testuser;

--
-- Name: outputs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: testuser
--

ALTER SEQUENCE public.outputs_id_seq OWNED BY public.outputs.id;


--
-- Name: power_connector_connection_configurations; Type: TABLE; Schema: public; Owner: testuser
--

CREATE TABLE public.power_connector_connection_configurations (
    id integer NOT NULL,
    power_connector_id integer NOT NULL,
    connection_configuration_id integer NOT NULL
);


ALTER TABLE public.power_connector_connection_configurations OWNER TO testuser;

--
-- Name: power_connector_connection_configurations_id_seq; Type: SEQUENCE; Schema: public; Owner: testuser
--

CREATE SEQUENCE public.power_connector_connection_configurations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.power_connector_connection_configurations_id_seq OWNER TO testuser;

--
-- Name: power_connector_connection_configurations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: testuser
--

ALTER SEQUENCE public.power_connector_connection_configurations_id_seq OWNED BY public.power_connector_connection_configurations.id;


--
-- Name: power_connectors; Type: TABLE; Schema: public; Owner: testuser
--

CREATE TABLE public.power_connectors (
    id integer NOT NULL,
    name character varying NOT NULL
);


ALTER TABLE public.power_connectors OWNER TO testuser;

--
-- Name: power_connectors_id_seq; Type: SEQUENCE; Schema: public; Owner: testuser
--

CREATE SEQUENCE public.power_connectors_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.power_connectors_id_seq OWNER TO testuser;

--
-- Name: power_connectors_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: testuser
--

ALTER SEQUENCE public.power_connectors_id_seq OWNED BY public.power_connectors.id;


--
-- Name: power_supplies; Type: TABLE; Schema: public; Owner: testuser
--

CREATE TABLE public.power_supplies (
    id integer NOT NULL,
    brand_id integer NOT NULL,
    series_id integer NOT NULL,
    model character varying NOT NULL,
    max_power_w integer NOT NULL,
    energy_efficiency_id integer NOT NULL,
    modularity_id integer NOT NULL,
    image_url character varying NOT NULL
);


ALTER TABLE public.power_supplies OWNER TO testuser;

--
-- Name: power_supplies_id_seq; Type: SEQUENCE; Schema: public; Owner: testuser
--

CREATE SEQUENCE public.power_supplies_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.power_supplies_id_seq OWNER TO testuser;

--
-- Name: power_supplies_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: testuser
--

ALTER SEQUENCE public.power_supplies_id_seq OWNED BY public.power_supplies.id;


--
-- Name: processors; Type: TABLE; Schema: public; Owner: testuser
--

CREATE TABLE public.processors (
    id integer NOT NULL,
    brand_id integer NOT NULL,
    name character varying NOT NULL,
    series_id integer NOT NULL,
    socket_id integer NOT NULL,
    number_of_cores integer NOT NULL,
    number_of_threads integer NOT NULL,
    memory_type_id integer NOT NULL,
    max_memory_supported_gb integer NOT NULL,
    max_memory_speed_mhz integer NOT NULL,
    operating_frequency_mhz double precision NOT NULL,
    turbo_frequency_mhz double precision NOT NULL,
    thermal_design_power_w integer NOT NULL,
    cooling_device_included boolean NOT NULL,
    integrated_graphics_id integer,
    image_url character varying NOT NULL
);


ALTER TABLE public.processors OWNER TO testuser;

--
-- Name: processors_id_seq; Type: SEQUENCE; Schema: public; Owner: testuser
--

CREATE SEQUENCE public.processors_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.processors_id_seq OWNER TO testuser;

--
-- Name: processors_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: testuser
--

ALTER SEQUENCE public.processors_id_seq OWNED BY public.processors.id;


--
-- Name: products; Type: TABLE; Schema: public; Owner: testuser
--

CREATE TABLE public.products (
    id integer NOT NULL,
    vendor_id integer NOT NULL,
    part_id integer NOT NULL,
    type character varying NOT NULL,
    price money NOT NULL
);


ALTER TABLE public.products OWNER TO testuser;

--
-- Name: products_id_seq; Type: SEQUENCE; Schema: public; Owner: testuser
--

CREATE SEQUENCE public.products_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.products_id_seq OWNER TO testuser;

--
-- Name: products_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: testuser
--

ALTER SEQUENCE public.products_id_seq OWNED BY public.products.id;


--
-- Name: psu_adapters; Type: TABLE; Schema: public; Owner: testuser
--

CREATE TABLE public.psu_adapters (
    id integer NOT NULL,
    power_supply_id integer NOT NULL,
    adapter_id integer NOT NULL,
    quantity integer NOT NULL
);


ALTER TABLE public.psu_adapters OWNER TO testuser;

--
-- Name: psu_adapters_id_seq; Type: SEQUENCE; Schema: public; Owner: testuser
--

CREATE SEQUENCE public.psu_adapters_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.psu_adapters_id_seq OWNER TO testuser;

--
-- Name: psu_adapters_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: testuser
--

ALTER SEQUENCE public.psu_adapters_id_seq OWNED BY public.psu_adapters.id;


--
-- Name: psu_power_connectors; Type: TABLE; Schema: public; Owner: testuser
--

CREATE TABLE public.psu_power_connectors (
    id integer NOT NULL,
    power_supply_id integer NOT NULL,
    power_connector_id integer NOT NULL,
    cable_count integer NOT NULL,
    connector_count integer NOT NULL
);


ALTER TABLE public.psu_power_connectors OWNER TO testuser;

--
-- Name: psu_power_connectors_id_seq; Type: SEQUENCE; Schema: public; Owner: testuser
--

CREATE SEQUENCE public.psu_power_connectors_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.psu_power_connectors_id_seq OWNER TO testuser;

--
-- Name: psu_power_connectors_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: testuser
--

ALTER SEQUENCE public.psu_power_connectors_id_seq OWNED BY public.psu_power_connectors.id;


--
-- Name: psu_series; Type: TABLE; Schema: public; Owner: testuser
--

CREATE TABLE public.psu_series (
    id integer NOT NULL,
    name character varying NOT NULL
);


ALTER TABLE public.psu_series OWNER TO testuser;

--
-- Name: psu_series_id_seq; Type: SEQUENCE; Schema: public; Owner: testuser
--

CREATE SEQUENCE public.psu_series_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.psu_series_id_seq OWNER TO testuser;

--
-- Name: psu_series_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: testuser
--

ALTER SEQUENCE public.psu_series_id_seq OWNED BY public.psu_series.id;


--
-- Name: ram_memory_types; Type: TABLE; Schema: public; Owner: testuser
--

CREATE TABLE public.ram_memory_types (
    id integer NOT NULL,
    name character varying NOT NULL
);


ALTER TABLE public.ram_memory_types OWNER TO testuser;

--
-- Name: ram_memory_types_id_seq; Type: SEQUENCE; Schema: public; Owner: testuser
--

CREATE SEQUENCE public.ram_memory_types_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.ram_memory_types_id_seq OWNER TO testuser;

--
-- Name: ram_memory_types_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: testuser
--

ALTER SEQUENCE public.ram_memory_types_id_seq OWNED BY public.ram_memory_types.id;


--
-- Name: ram_series; Type: TABLE; Schema: public; Owner: testuser
--

CREATE TABLE public.ram_series (
    id integer NOT NULL,
    name character varying NOT NULL
);


ALTER TABLE public.ram_series OWNER TO testuser;

--
-- Name: ram_series_id_seq; Type: SEQUENCE; Schema: public; Owner: testuser
--

CREATE SEQUENCE public.ram_series_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.ram_series_id_seq OWNER TO testuser;

--
-- Name: ram_series_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: testuser
--

ALTER SEQUENCE public.ram_series_id_seq OWNED BY public.ram_series.id;


--
-- Name: random_access_memory; Type: TABLE; Schema: public; Owner: testuser
--

CREATE TABLE public.random_access_memory (
    id integer NOT NULL,
    brand_id integer NOT NULL,
    series_id integer NOT NULL,
    model character varying NOT NULL,
    memory_type_id integer NOT NULL,
    timing character varying NOT NULL,
    cas_latency integer NOT NULL,
    voltage double precision NOT NULL,
    transfer_rate_mb_s integer NOT NULL,
    speed_mhz integer NOT NULL,
    modules integer NOT NULL,
    module_capacity_gb integer NOT NULL,
    total_capacity_gb integer NOT NULL,
    image_url character varying NOT NULL
);


ALTER TABLE public.random_access_memory OWNER TO testuser;

--
-- Name: random_access_memory_id_seq; Type: SEQUENCE; Schema: public; Owner: testuser
--

CREATE SEQUENCE public.random_access_memory_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.random_access_memory_id_seq OWNER TO testuser;

--
-- Name: random_access_memory_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: testuser
--

ALTER SEQUENCE public.random_access_memory_id_seq OWNED BY public.random_access_memory.id;


--
-- Name: sockets; Type: TABLE; Schema: public; Owner: testuser
--

CREATE TABLE public.sockets (
    id integer NOT NULL,
    name character varying NOT NULL
);


ALTER TABLE public.sockets OWNER TO testuser;

--
-- Name: sockets_id_seq; Type: SEQUENCE; Schema: public; Owner: testuser
--

CREATE SEQUENCE public.sockets_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.sockets_id_seq OWNER TO testuser;

--
-- Name: sockets_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: testuser
--

ALTER SEQUENCE public.sockets_id_seq OWNED BY public.sockets.id;


--
-- Name: vendors; Type: TABLE; Schema: public; Owner: testuser
--

CREATE TABLE public.vendors (
    id integer NOT NULL,
    name character varying NOT NULL,
    key character varying NOT NULL
);


ALTER TABLE public.vendors OWNER TO testuser;

--
-- Name: vendors_id_seq; Type: SEQUENCE; Schema: public; Owner: testuser
--

CREATE SEQUENCE public.vendors_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.vendors_id_seq OWNER TO testuser;

--
-- Name: vendors_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: testuser
--

ALTER SEQUENCE public.vendors_id_seq OWNED BY public.vendors.id;


--
-- Name: adapters id; Type: DEFAULT; Schema: public; Owner: testuser
--

ALTER TABLE ONLY public.adapters ALTER COLUMN id SET DEFAULT nextval('public.adapters_id_seq'::regclass);


--
-- Name: brands id; Type: DEFAULT; Schema: public; Owner: testuser
--

ALTER TABLE ONLY public.brands ALTER COLUMN id SET DEFAULT nextval('public.brands_id_seq'::regclass);


--
-- Name: builds id; Type: DEFAULT; Schema: public; Owner: testuser
--

ALTER TABLE ONLY public.builds ALTER COLUMN id SET DEFAULT nextval('public.builds_id_seq'::regclass);


--
-- Name: connection_configurations id; Type: DEFAULT; Schema: public; Owner: testuser
--

ALTER TABLE ONLY public.connection_configurations ALTER COLUMN id SET DEFAULT nextval('public.connection_configurations_id_seq'::regclass);


--
-- Name: cpu_series id; Type: DEFAULT; Schema: public; Owner: testuser
--

ALTER TABLE ONLY public.cpu_series ALTER COLUMN id SET DEFAULT nextval('public.cpu_series_id_seq'::regclass);


--
-- Name: drive_form_factors id; Type: DEFAULT; Schema: public; Owner: testuser
--

ALTER TABLE ONLY public.drive_form_factors ALTER COLUMN id SET DEFAULT nextval('public.drive_form_factors_id_seq'::regclass);


--
-- Name: drive_series id; Type: DEFAULT; Schema: public; Owner: testuser
--

ALTER TABLE ONLY public.drive_series ALTER COLUMN id SET DEFAULT nextval('public.drive_series_id_seq'::regclass);


--
-- Name: drive_types id; Type: DEFAULT; Schema: public; Owner: testuser
--

ALTER TABLE ONLY public.drive_types ALTER COLUMN id SET DEFAULT nextval('public.drive_types_id_seq'::regclass);


--
-- Name: drives id; Type: DEFAULT; Schema: public; Owner: testuser
--

ALTER TABLE ONLY public.drives ALTER COLUMN id SET DEFAULT nextval('public.drives_id_seq'::regclass);


--
-- Name: energy_efficiencies id; Type: DEFAULT; Schema: public; Owner: testuser
--

ALTER TABLE ONLY public.energy_efficiencies ALTER COLUMN id SET DEFAULT nextval('public.energy_efficiencies_id_seq'::regclass);


--
-- Name: gpu_chipset_manufacturers id; Type: DEFAULT; Schema: public; Owner: testuser
--

ALTER TABLE ONLY public.gpu_chipset_manufacturers ALTER COLUMN id SET DEFAULT nextval('public.gpu_chipset_manufacturers_id_seq'::regclass);


--
-- Name: gpu_memory_types id; Type: DEFAULT; Schema: public; Owner: testuser
--

ALTER TABLE ONLY public.gpu_memory_types ALTER COLUMN id SET DEFAULT nextval('public.gpu_memory_types_id_seq'::regclass);


--
-- Name: gpu_outputs id; Type: DEFAULT; Schema: public; Owner: testuser
--

ALTER TABLE ONLY public.gpu_outputs ALTER COLUMN id SET DEFAULT nextval('public.gpu_outputs_id_seq'::regclass);


--
-- Name: gpu_power_connectors id; Type: DEFAULT; Schema: public; Owner: testuser
--

ALTER TABLE ONLY public.gpu_power_connectors ALTER COLUMN id SET DEFAULT nextval('public.gpu_power_connectors_id_seq'::regclass);


--
-- Name: graphics_cards id; Type: DEFAULT; Schema: public; Owner: testuser
--

ALTER TABLE ONLY public.graphics_cards ALTER COLUMN id SET DEFAULT nextval('public.graphics_cards_id_seq'::regclass);


--
-- Name: integrated_graphics id; Type: DEFAULT; Schema: public; Owner: testuser
--

ALTER TABLE ONLY public.integrated_graphics ALTER COLUMN id SET DEFAULT nextval('public.integrated_graphics_id_seq'::regclass);


--
-- Name: interfaces id; Type: DEFAULT; Schema: public; Owner: testuser
--

ALTER TABLE ONLY public.interfaces ALTER COLUMN id SET DEFAULT nextval('public.interfaces_id_seq'::regclass);


--
-- Name: mb_chipset_manufacturers id; Type: DEFAULT; Schema: public; Owner: testuser
--

ALTER TABLE ONLY public.mb_chipset_manufacturers ALTER COLUMN id SET DEFAULT nextval('public.mb_chipset_manufacturers_id_seq'::regclass);


--
-- Name: mb_chipsets id; Type: DEFAULT; Schema: public; Owner: testuser
--

ALTER TABLE ONLY public.mb_chipsets ALTER COLUMN id SET DEFAULT nextval('public.mb_chipsets_id_seq'::regclass);


--
-- Name: mb_form_factors id; Type: DEFAULT; Schema: public; Owner: testuser
--

ALTER TABLE ONLY public.mb_form_factors ALTER COLUMN id SET DEFAULT nextval('public.mb_form_factors_id_seq'::regclass);


--
-- Name: mb_interfaces id; Type: DEFAULT; Schema: public; Owner: testuser
--

ALTER TABLE ONLY public.mb_interfaces ALTER COLUMN id SET DEFAULT nextval('public.mb_interfaces_id_seq'::regclass);


--
-- Name: mb_outputs id; Type: DEFAULT; Schema: public; Owner: testuser
--

ALTER TABLE ONLY public.mb_outputs ALTER COLUMN id SET DEFAULT nextval('public.mb_outputs_id_seq'::regclass);


--
-- Name: modularity id; Type: DEFAULT; Schema: public; Owner: testuser
--

ALTER TABLE ONLY public.modularity ALTER COLUMN id SET DEFAULT nextval('public.modularity_id_seq'::regclass);


--
-- Name: motherboards id; Type: DEFAULT; Schema: public; Owner: testuser
--

ALTER TABLE ONLY public.motherboards ALTER COLUMN id SET DEFAULT nextval('public.motherboards_id_seq'::regclass);


--
-- Name: outputs id; Type: DEFAULT; Schema: public; Owner: testuser
--

ALTER TABLE ONLY public.outputs ALTER COLUMN id SET DEFAULT nextval('public.outputs_id_seq'::regclass);


--
-- Name: power_connector_connection_configurations id; Type: DEFAULT; Schema: public; Owner: testuser
--

ALTER TABLE ONLY public.power_connector_connection_configurations ALTER COLUMN id SET DEFAULT nextval('public.power_connector_connection_configurations_id_seq'::regclass);


--
-- Name: power_connectors id; Type: DEFAULT; Schema: public; Owner: testuser
--

ALTER TABLE ONLY public.power_connectors ALTER COLUMN id SET DEFAULT nextval('public.power_connectors_id_seq'::regclass);


--
-- Name: power_supplies id; Type: DEFAULT; Schema: public; Owner: testuser
--

ALTER TABLE ONLY public.power_supplies ALTER COLUMN id SET DEFAULT nextval('public.power_supplies_id_seq'::regclass);


--
-- Name: processors id; Type: DEFAULT; Schema: public; Owner: testuser
--

ALTER TABLE ONLY public.processors ALTER COLUMN id SET DEFAULT nextval('public.processors_id_seq'::regclass);


--
-- Name: products id; Type: DEFAULT; Schema: public; Owner: testuser
--

ALTER TABLE ONLY public.products ALTER COLUMN id SET DEFAULT nextval('public.products_id_seq'::regclass);


--
-- Name: psu_adapters id; Type: DEFAULT; Schema: public; Owner: testuser
--

ALTER TABLE ONLY public.psu_adapters ALTER COLUMN id SET DEFAULT nextval('public.psu_adapters_id_seq'::regclass);


--
-- Name: psu_power_connectors id; Type: DEFAULT; Schema: public; Owner: testuser
--

ALTER TABLE ONLY public.psu_power_connectors ALTER COLUMN id SET DEFAULT nextval('public.psu_power_connectors_id_seq'::regclass);


--
-- Name: psu_series id; Type: DEFAULT; Schema: public; Owner: testuser
--

ALTER TABLE ONLY public.psu_series ALTER COLUMN id SET DEFAULT nextval('public.psu_series_id_seq'::regclass);


--
-- Name: ram_memory_types id; Type: DEFAULT; Schema: public; Owner: testuser
--

ALTER TABLE ONLY public.ram_memory_types ALTER COLUMN id SET DEFAULT nextval('public.ram_memory_types_id_seq'::regclass);


--
-- Name: ram_series id; Type: DEFAULT; Schema: public; Owner: testuser
--

ALTER TABLE ONLY public.ram_series ALTER COLUMN id SET DEFAULT nextval('public.ram_series_id_seq'::regclass);


--
-- Name: random_access_memory id; Type: DEFAULT; Schema: public; Owner: testuser
--

ALTER TABLE ONLY public.random_access_memory ALTER COLUMN id SET DEFAULT nextval('public.random_access_memory_id_seq'::regclass);


--
-- Name: sockets id; Type: DEFAULT; Schema: public; Owner: testuser
--

ALTER TABLE ONLY public.sockets ALTER COLUMN id SET DEFAULT nextval('public.sockets_id_seq'::regclass);


--
-- Name: vendors id; Type: DEFAULT; Schema: public; Owner: testuser
--

ALTER TABLE ONLY public.vendors ALTER COLUMN id SET DEFAULT nextval('public.vendors_id_seq'::regclass);


--
-- Data for Name: adapters; Type: TABLE DATA; Schema: public; Owner: testuser
--

COPY public.adapters (id, name) FROM stdin;
\.
COPY public.adapters (id, name) FROM '$$PATH$$/3684.dat';

--
-- Data for Name: brands; Type: TABLE DATA; Schema: public; Owner: testuser
--

COPY public.brands (id, name) FROM stdin;
\.
COPY public.brands (id, name) FROM '$$PATH$$/3646.dat';

--
-- Data for Name: builds; Type: TABLE DATA; Schema: public; Owner: testuser
--

COPY public.builds (id, processor_id, graphics_card_id, motherboard_id, power_supply_id, random_access_memory_id, drive_id, popularity) FROM stdin;
\.
COPY public.builds (id, processor_id, graphics_card_id, motherboard_id, power_supply_id, random_access_memory_id, drive_id, popularity) FROM '$$PATH$$/3720.dat';

--
-- Data for Name: connection_configurations; Type: TABLE DATA; Schema: public; Owner: testuser
--

COPY public.connection_configurations (id, name) FROM stdin;
\.
COPY public.connection_configurations (id, name) FROM '$$PATH$$/3688.dat';

--
-- Data for Name: cpu_series; Type: TABLE DATA; Schema: public; Owner: testuser
--

COPY public.cpu_series (id, name) FROM stdin;
\.
COPY public.cpu_series (id, name) FROM '$$PATH$$/3648.dat';

--
-- Data for Name: drive_form_factors; Type: TABLE DATA; Schema: public; Owner: testuser
--

COPY public.drive_form_factors (id, name) FROM stdin;
\.
COPY public.drive_form_factors (id, name) FROM '$$PATH$$/3658.dat';

--
-- Data for Name: drive_series; Type: TABLE DATA; Schema: public; Owner: testuser
--

COPY public.drive_series (id, name) FROM stdin;
\.
COPY public.drive_series (id, name) FROM '$$PATH$$/3654.dat';

--
-- Data for Name: drive_types; Type: TABLE DATA; Schema: public; Owner: testuser
--

COPY public.drive_types (id, name) FROM stdin;
\.
COPY public.drive_types (id, name) FROM '$$PATH$$/3656.dat';

--
-- Data for Name: drives; Type: TABLE DATA; Schema: public; Owner: testuser
--

COPY public.drives (id, brand_id, series_id, drive_type_id, form_factor_id, model, capacity_gb, max_read_mb_s, max_write_mb_s, interface_id, image_url) FROM stdin;
\.
COPY public.drives (id, brand_id, series_id, drive_type_id, form_factor_id, model, capacity_gb, max_read_mb_s, max_write_mb_s, interface_id, image_url) FROM '$$PATH$$/3660.dat';

--
-- Data for Name: energy_efficiencies; Type: TABLE DATA; Schema: public; Owner: testuser
--

COPY public.energy_efficiencies (id, name) FROM stdin;
\.
COPY public.energy_efficiencies (id, name) FROM '$$PATH$$/3690.dat';

--
-- Data for Name: gpu_chipset_manufacturers; Type: TABLE DATA; Schema: public; Owner: testuser
--

COPY public.gpu_chipset_manufacturers (id, name) FROM stdin;
\.
COPY public.gpu_chipset_manufacturers (id, name) FROM '$$PATH$$/3662.dat';

--
-- Data for Name: gpu_memory_types; Type: TABLE DATA; Schema: public; Owner: testuser
--

COPY public.gpu_memory_types (id, name) FROM stdin;
\.
COPY public.gpu_memory_types (id, name) FROM '$$PATH$$/3664.dat';

--
-- Data for Name: gpu_outputs; Type: TABLE DATA; Schema: public; Owner: testuser
--

COPY public.gpu_outputs (id, graphics_card_id, output_id, quantity) FROM stdin;
\.
COPY public.gpu_outputs (id, graphics_card_id, output_id, quantity) FROM '$$PATH$$/3666.dat';

--
-- Data for Name: gpu_power_connectors; Type: TABLE DATA; Schema: public; Owner: testuser
--

COPY public.gpu_power_connectors (id, graphics_card_id, power_connector_id, quantity) FROM stdin;
\.
COPY public.gpu_power_connectors (id, graphics_card_id, power_connector_id, quantity) FROM '$$PATH$$/3668.dat';

--
-- Data for Name: graphics_cards; Type: TABLE DATA; Schema: public; Owner: testuser
--

COPY public.graphics_cards (id, brand_id, name, model, chipset_manufacturer_id, memory_type_id, memory_size_gb, thermal_design_power_w, slot_width_inches, interface_id, image_url) FROM stdin;
\.
COPY public.graphics_cards (id, brand_id, name, model, chipset_manufacturer_id, memory_type_id, memory_size_gb, thermal_design_power_w, slot_width_inches, interface_id, image_url) FROM '$$PATH$$/3670.dat';

--
-- Data for Name: integrated_graphics; Type: TABLE DATA; Schema: public; Owner: testuser
--

COPY public.integrated_graphics (id, name) FROM stdin;
\.
COPY public.integrated_graphics (id, name) FROM '$$PATH$$/3650.dat';

--
-- Data for Name: interfaces; Type: TABLE DATA; Schema: public; Owner: testuser
--

COPY public.interfaces (id, name, version) FROM stdin;
\.
COPY public.interfaces (id, name, version) FROM '$$PATH$$/3710.dat';

--
-- Data for Name: mb_chipset_manufacturers; Type: TABLE DATA; Schema: public; Owner: testuser
--

COPY public.mb_chipset_manufacturers (id, name) FROM stdin;
\.
COPY public.mb_chipset_manufacturers (id, name) FROM '$$PATH$$/3672.dat';

--
-- Data for Name: mb_chipsets; Type: TABLE DATA; Schema: public; Owner: testuser
--

COPY public.mb_chipsets (id, name, manufacturer_id) FROM stdin;
\.
COPY public.mb_chipsets (id, name, manufacturer_id) FROM '$$PATH$$/3674.dat';

--
-- Data for Name: mb_form_factors; Type: TABLE DATA; Schema: public; Owner: testuser
--

COPY public.mb_form_factors (id, name) FROM stdin;
\.
COPY public.mb_form_factors (id, name) FROM '$$PATH$$/3676.dat';

--
-- Data for Name: mb_interfaces; Type: TABLE DATA; Schema: public; Owner: testuser
--

COPY public.mb_interfaces (id, motherboard_id, interface_id, quantity, type) FROM stdin;
\.
COPY public.mb_interfaces (id, motherboard_id, interface_id, quantity, type) FROM '$$PATH$$/3678.dat';

--
-- Data for Name: mb_outputs; Type: TABLE DATA; Schema: public; Owner: testuser
--

COPY public.mb_outputs (id, motherboard_id, output_id, quantity) FROM stdin;
\.
COPY public.mb_outputs (id, motherboard_id, output_id, quantity) FROM '$$PATH$$/3680.dat';

--
-- Data for Name: modularity; Type: TABLE DATA; Schema: public; Owner: testuser
--

COPY public.modularity (id, name) FROM stdin;
\.
COPY public.modularity (id, name) FROM '$$PATH$$/3692.dat';

--
-- Data for Name: motherboards; Type: TABLE DATA; Schema: public; Owner: testuser
--

COPY public.motherboards (id, brand_id, model, socket_id, chipset_id, form_factor_id, memory_type_id, max_memory_supported_gb, memory_slots, image_url) FROM stdin;
\.
COPY public.motherboards (id, brand_id, model, socket_id, chipset_id, form_factor_id, memory_type_id, max_memory_supported_gb, memory_slots, image_url) FROM '$$PATH$$/3682.dat';

--
-- Data for Name: outputs; Type: TABLE DATA; Schema: public; Owner: testuser
--

COPY public.outputs (id, name) FROM stdin;
\.
COPY public.outputs (id, name) FROM '$$PATH$$/3712.dat';

--
-- Data for Name: power_connector_connection_configurations; Type: TABLE DATA; Schema: public; Owner: testuser
--

COPY public.power_connector_connection_configurations (id, power_connector_id, connection_configuration_id) FROM stdin;
\.
COPY public.power_connector_connection_configurations (id, power_connector_id, connection_configuration_id) FROM '$$PATH$$/3686.dat';

--
-- Data for Name: power_connectors; Type: TABLE DATA; Schema: public; Owner: testuser
--

COPY public.power_connectors (id, name) FROM stdin;
\.
COPY public.power_connectors (id, name) FROM '$$PATH$$/3694.dat';

--
-- Data for Name: power_supplies; Type: TABLE DATA; Schema: public; Owner: testuser
--

COPY public.power_supplies (id, brand_id, series_id, model, max_power_w, energy_efficiency_id, modularity_id, image_url) FROM stdin;
\.
COPY public.power_supplies (id, brand_id, series_id, model, max_power_w, energy_efficiency_id, modularity_id, image_url) FROM '$$PATH$$/3702.dat';

--
-- Data for Name: processors; Type: TABLE DATA; Schema: public; Owner: testuser
--

COPY public.processors (id, brand_id, name, series_id, socket_id, number_of_cores, number_of_threads, memory_type_id, max_memory_supported_gb, max_memory_speed_mhz, operating_frequency_mhz, turbo_frequency_mhz, thermal_design_power_w, cooling_device_included, integrated_graphics_id, image_url) FROM stdin;
\.
COPY public.processors (id, brand_id, name, series_id, socket_id, number_of_cores, number_of_threads, memory_type_id, max_memory_supported_gb, max_memory_speed_mhz, operating_frequency_mhz, turbo_frequency_mhz, thermal_design_power_w, cooling_device_included, integrated_graphics_id, image_url) FROM '$$PATH$$/3652.dat';

--
-- Data for Name: products; Type: TABLE DATA; Schema: public; Owner: testuser
--

COPY public.products (id, vendor_id, part_id, type, price) FROM stdin;
\.
COPY public.products (id, vendor_id, part_id, type, price) FROM '$$PATH$$/3718.dat';

--
-- Data for Name: psu_adapters; Type: TABLE DATA; Schema: public; Owner: testuser
--

COPY public.psu_adapters (id, power_supply_id, adapter_id, quantity) FROM stdin;
\.
COPY public.psu_adapters (id, power_supply_id, adapter_id, quantity) FROM '$$PATH$$/3698.dat';

--
-- Data for Name: psu_power_connectors; Type: TABLE DATA; Schema: public; Owner: testuser
--

COPY public.psu_power_connectors (id, power_supply_id, power_connector_id, cable_count, connector_count) FROM stdin;
\.
COPY public.psu_power_connectors (id, power_supply_id, power_connector_id, cable_count, connector_count) FROM '$$PATH$$/3700.dat';

--
-- Data for Name: psu_series; Type: TABLE DATA; Schema: public; Owner: testuser
--

COPY public.psu_series (id, name) FROM stdin;
\.
COPY public.psu_series (id, name) FROM '$$PATH$$/3696.dat';

--
-- Data for Name: ram_memory_types; Type: TABLE DATA; Schema: public; Owner: testuser
--

COPY public.ram_memory_types (id, name) FROM stdin;
\.
COPY public.ram_memory_types (id, name) FROM '$$PATH$$/3704.dat';

--
-- Data for Name: ram_series; Type: TABLE DATA; Schema: public; Owner: testuser
--

COPY public.ram_series (id, name) FROM stdin;
\.
COPY public.ram_series (id, name) FROM '$$PATH$$/3706.dat';

--
-- Data for Name: random_access_memory; Type: TABLE DATA; Schema: public; Owner: testuser
--

COPY public.random_access_memory (id, brand_id, series_id, model, memory_type_id, timing, cas_latency, voltage, transfer_rate_mb_s, speed_mhz, modules, module_capacity_gb, total_capacity_gb, image_url) FROM stdin;
\.
COPY public.random_access_memory (id, brand_id, series_id, model, memory_type_id, timing, cas_latency, voltage, transfer_rate_mb_s, speed_mhz, modules, module_capacity_gb, total_capacity_gb, image_url) FROM '$$PATH$$/3708.dat';

--
-- Data for Name: sockets; Type: TABLE DATA; Schema: public; Owner: testuser
--

COPY public.sockets (id, name) FROM stdin;
\.
COPY public.sockets (id, name) FROM '$$PATH$$/3714.dat';

--
-- Data for Name: vendors; Type: TABLE DATA; Schema: public; Owner: testuser
--

COPY public.vendors (id, name, key) FROM stdin;
\.
COPY public.vendors (id, name, key) FROM '$$PATH$$/3716.dat';

--
-- Name: adapters_id_seq; Type: SEQUENCE SET; Schema: public; Owner: testuser
--

SELECT pg_catalog.setval('public.adapters_id_seq', 1, false);


--
-- Name: brands_id_seq; Type: SEQUENCE SET; Schema: public; Owner: testuser
--

SELECT pg_catalog.setval('public.brands_id_seq', 1, false);


--
-- Name: builds_id_seq; Type: SEQUENCE SET; Schema: public; Owner: testuser
--

SELECT pg_catalog.setval('public.builds_id_seq', 6, true);


--
-- Name: connection_configurations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: testuser
--

SELECT pg_catalog.setval('public.connection_configurations_id_seq', 1, false);


--
-- Name: cpu_series_id_seq; Type: SEQUENCE SET; Schema: public; Owner: testuser
--

SELECT pg_catalog.setval('public.cpu_series_id_seq', 1, false);


--
-- Name: drive_form_factors_id_seq; Type: SEQUENCE SET; Schema: public; Owner: testuser
--

SELECT pg_catalog.setval('public.drive_form_factors_id_seq', 1, false);


--
-- Name: drive_series_id_seq; Type: SEQUENCE SET; Schema: public; Owner: testuser
--

SELECT pg_catalog.setval('public.drive_series_id_seq', 1, false);


--
-- Name: drive_types_id_seq; Type: SEQUENCE SET; Schema: public; Owner: testuser
--

SELECT pg_catalog.setval('public.drive_types_id_seq', 1, false);


--
-- Name: drives_id_seq; Type: SEQUENCE SET; Schema: public; Owner: testuser
--

SELECT pg_catalog.setval('public.drives_id_seq', 1, false);


--
-- Name: energy_efficiencies_id_seq; Type: SEQUENCE SET; Schema: public; Owner: testuser
--

SELECT pg_catalog.setval('public.energy_efficiencies_id_seq', 1, false);


--
-- Name: gpu_chipset_manufacturers_id_seq; Type: SEQUENCE SET; Schema: public; Owner: testuser
--

SELECT pg_catalog.setval('public.gpu_chipset_manufacturers_id_seq', 1, false);


--
-- Name: gpu_memory_types_id_seq; Type: SEQUENCE SET; Schema: public; Owner: testuser
--

SELECT pg_catalog.setval('public.gpu_memory_types_id_seq', 1, false);


--
-- Name: gpu_outputs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: testuser
--

SELECT pg_catalog.setval('public.gpu_outputs_id_seq', 1, false);


--
-- Name: gpu_power_connectors_id_seq; Type: SEQUENCE SET; Schema: public; Owner: testuser
--

SELECT pg_catalog.setval('public.gpu_power_connectors_id_seq', 1, false);


--
-- Name: graphics_cards_id_seq; Type: SEQUENCE SET; Schema: public; Owner: testuser
--

SELECT pg_catalog.setval('public.graphics_cards_id_seq', 1, false);


--
-- Name: integrated_graphics_id_seq; Type: SEQUENCE SET; Schema: public; Owner: testuser
--

SELECT pg_catalog.setval('public.integrated_graphics_id_seq', 1, false);


--
-- Name: interfaces_id_seq; Type: SEQUENCE SET; Schema: public; Owner: testuser
--

SELECT pg_catalog.setval('public.interfaces_id_seq', 1, false);


--
-- Name: mb_chipset_manufacturers_id_seq; Type: SEQUENCE SET; Schema: public; Owner: testuser
--

SELECT pg_catalog.setval('public.mb_chipset_manufacturers_id_seq', 1, false);


--
-- Name: mb_chipsets_id_seq; Type: SEQUENCE SET; Schema: public; Owner: testuser
--

SELECT pg_catalog.setval('public.mb_chipsets_id_seq', 1, false);


--
-- Name: mb_form_factors_id_seq; Type: SEQUENCE SET; Schema: public; Owner: testuser
--

SELECT pg_catalog.setval('public.mb_form_factors_id_seq', 1, false);


--
-- Name: mb_interfaces_id_seq; Type: SEQUENCE SET; Schema: public; Owner: testuser
--

SELECT pg_catalog.setval('public.mb_interfaces_id_seq', 1, false);


--
-- Name: mb_outputs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: testuser
--

SELECT pg_catalog.setval('public.mb_outputs_id_seq', 1, false);


--
-- Name: modularity_id_seq; Type: SEQUENCE SET; Schema: public; Owner: testuser
--

SELECT pg_catalog.setval('public.modularity_id_seq', 1, false);


--
-- Name: motherboards_id_seq; Type: SEQUENCE SET; Schema: public; Owner: testuser
--

SELECT pg_catalog.setval('public.motherboards_id_seq', 1, false);


--
-- Name: outputs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: testuser
--

SELECT pg_catalog.setval('public.outputs_id_seq', 1, false);


--
-- Name: power_connector_connection_configurations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: testuser
--

SELECT pg_catalog.setval('public.power_connector_connection_configurations_id_seq', 1, false);


--
-- Name: power_connectors_id_seq; Type: SEQUENCE SET; Schema: public; Owner: testuser
--

SELECT pg_catalog.setval('public.power_connectors_id_seq', 1, false);


--
-- Name: power_supplies_id_seq; Type: SEQUENCE SET; Schema: public; Owner: testuser
--

SELECT pg_catalog.setval('public.power_supplies_id_seq', 1, false);


--
-- Name: processors_id_seq; Type: SEQUENCE SET; Schema: public; Owner: testuser
--

SELECT pg_catalog.setval('public.processors_id_seq', 1, false);


--
-- Name: products_id_seq; Type: SEQUENCE SET; Schema: public; Owner: testuser
--

SELECT pg_catalog.setval('public.products_id_seq', 1, false);


--
-- Name: psu_adapters_id_seq; Type: SEQUENCE SET; Schema: public; Owner: testuser
--

SELECT pg_catalog.setval('public.psu_adapters_id_seq', 1, false);


--
-- Name: psu_power_connectors_id_seq; Type: SEQUENCE SET; Schema: public; Owner: testuser
--

SELECT pg_catalog.setval('public.psu_power_connectors_id_seq', 1, false);


--
-- Name: psu_series_id_seq; Type: SEQUENCE SET; Schema: public; Owner: testuser
--

SELECT pg_catalog.setval('public.psu_series_id_seq', 1, false);


--
-- Name: ram_memory_types_id_seq; Type: SEQUENCE SET; Schema: public; Owner: testuser
--

SELECT pg_catalog.setval('public.ram_memory_types_id_seq', 1, false);


--
-- Name: ram_series_id_seq; Type: SEQUENCE SET; Schema: public; Owner: testuser
--

SELECT pg_catalog.setval('public.ram_series_id_seq', 1, false);


--
-- Name: random_access_memory_id_seq; Type: SEQUENCE SET; Schema: public; Owner: testuser
--

SELECT pg_catalog.setval('public.random_access_memory_id_seq', 1, false);


--
-- Name: sockets_id_seq; Type: SEQUENCE SET; Schema: public; Owner: testuser
--

SELECT pg_catalog.setval('public.sockets_id_seq', 1, false);


--
-- Name: vendors_id_seq; Type: SEQUENCE SET; Schema: public; Owner: testuser
--

SELECT pg_catalog.setval('public.vendors_id_seq', 1, false);


--
-- Name: adapters adapters_pkey; Type: CONSTRAINT; Schema: public; Owner: testuser
--

ALTER TABLE ONLY public.adapters
    ADD CONSTRAINT adapters_pkey PRIMARY KEY (id);


--
-- Name: brands brands_pkey; Type: CONSTRAINT; Schema: public; Owner: testuser
--

ALTER TABLE ONLY public.brands
    ADD CONSTRAINT brands_pkey PRIMARY KEY (id);


--
-- Name: builds builds_pkey; Type: CONSTRAINT; Schema: public; Owner: testuser
--

ALTER TABLE ONLY public.builds
    ADD CONSTRAINT builds_pkey PRIMARY KEY (id);


--
-- Name: connection_configurations connection_configurations_pkey; Type: CONSTRAINT; Schema: public; Owner: testuser
--

ALTER TABLE ONLY public.connection_configurations
    ADD CONSTRAINT connection_configurations_pkey PRIMARY KEY (id);


--
-- Name: cpu_series cpu_series_pkey; Type: CONSTRAINT; Schema: public; Owner: testuser
--

ALTER TABLE ONLY public.cpu_series
    ADD CONSTRAINT cpu_series_pkey PRIMARY KEY (id);


--
-- Name: drive_form_factors drive_form_factors_pkey; Type: CONSTRAINT; Schema: public; Owner: testuser
--

ALTER TABLE ONLY public.drive_form_factors
    ADD CONSTRAINT drive_form_factors_pkey PRIMARY KEY (id);


--
-- Name: drive_series drive_series_pkey; Type: CONSTRAINT; Schema: public; Owner: testuser
--

ALTER TABLE ONLY public.drive_series
    ADD CONSTRAINT drive_series_pkey PRIMARY KEY (id);


--
-- Name: drive_types drive_types_pkey; Type: CONSTRAINT; Schema: public; Owner: testuser
--

ALTER TABLE ONLY public.drive_types
    ADD CONSTRAINT drive_types_pkey PRIMARY KEY (id);


--
-- Name: drives drives_pkey; Type: CONSTRAINT; Schema: public; Owner: testuser
--

ALTER TABLE ONLY public.drives
    ADD CONSTRAINT drives_pkey PRIMARY KEY (id);


--
-- Name: energy_efficiencies energy_efficiencies_pkey; Type: CONSTRAINT; Schema: public; Owner: testuser
--

ALTER TABLE ONLY public.energy_efficiencies
    ADD CONSTRAINT energy_efficiencies_pkey PRIMARY KEY (id);


--
-- Name: gpu_chipset_manufacturers gpu_chipset_manufacturers_pkey; Type: CONSTRAINT; Schema: public; Owner: testuser
--

ALTER TABLE ONLY public.gpu_chipset_manufacturers
    ADD CONSTRAINT gpu_chipset_manufacturers_pkey PRIMARY KEY (id);


--
-- Name: gpu_memory_types gpu_memory_types_pkey; Type: CONSTRAINT; Schema: public; Owner: testuser
--

ALTER TABLE ONLY public.gpu_memory_types
    ADD CONSTRAINT gpu_memory_types_pkey PRIMARY KEY (id);


--
-- Name: gpu_outputs gpu_outputs_pkey; Type: CONSTRAINT; Schema: public; Owner: testuser
--

ALTER TABLE ONLY public.gpu_outputs
    ADD CONSTRAINT gpu_outputs_pkey PRIMARY KEY (id);


--
-- Name: gpu_power_connectors gpu_power_connectors_pkey; Type: CONSTRAINT; Schema: public; Owner: testuser
--

ALTER TABLE ONLY public.gpu_power_connectors
    ADD CONSTRAINT gpu_power_connectors_pkey PRIMARY KEY (id);


--
-- Name: graphics_cards graphics_cards_pkey; Type: CONSTRAINT; Schema: public; Owner: testuser
--

ALTER TABLE ONLY public.graphics_cards
    ADD CONSTRAINT graphics_cards_pkey PRIMARY KEY (id);


--
-- Name: integrated_graphics integrated_graphics_pkey; Type: CONSTRAINT; Schema: public; Owner: testuser
--

ALTER TABLE ONLY public.integrated_graphics
    ADD CONSTRAINT integrated_graphics_pkey PRIMARY KEY (id);


--
-- Name: interfaces interfaces_pkey; Type: CONSTRAINT; Schema: public; Owner: testuser
--

ALTER TABLE ONLY public.interfaces
    ADD CONSTRAINT interfaces_pkey PRIMARY KEY (id);


--
-- Name: mb_chipset_manufacturers mb_chipset_manufacturers_pkey; Type: CONSTRAINT; Schema: public; Owner: testuser
--

ALTER TABLE ONLY public.mb_chipset_manufacturers
    ADD CONSTRAINT mb_chipset_manufacturers_pkey PRIMARY KEY (id);


--
-- Name: mb_chipsets mb_chipsets_pkey; Type: CONSTRAINT; Schema: public; Owner: testuser
--

ALTER TABLE ONLY public.mb_chipsets
    ADD CONSTRAINT mb_chipsets_pkey PRIMARY KEY (id);


--
-- Name: mb_form_factors mb_form_factors_pkey; Type: CONSTRAINT; Schema: public; Owner: testuser
--

ALTER TABLE ONLY public.mb_form_factors
    ADD CONSTRAINT mb_form_factors_pkey PRIMARY KEY (id);


--
-- Name: mb_interfaces mb_interfaces_pkey; Type: CONSTRAINT; Schema: public; Owner: testuser
--

ALTER TABLE ONLY public.mb_interfaces
    ADD CONSTRAINT mb_interfaces_pkey PRIMARY KEY (id);


--
-- Name: mb_outputs mb_outputs_pkey; Type: CONSTRAINT; Schema: public; Owner: testuser
--

ALTER TABLE ONLY public.mb_outputs
    ADD CONSTRAINT mb_outputs_pkey PRIMARY KEY (id);


--
-- Name: modularity modularity_pkey; Type: CONSTRAINT; Schema: public; Owner: testuser
--

ALTER TABLE ONLY public.modularity
    ADD CONSTRAINT modularity_pkey PRIMARY KEY (id);


--
-- Name: motherboards motherboards_pkey; Type: CONSTRAINT; Schema: public; Owner: testuser
--

ALTER TABLE ONLY public.motherboards
    ADD CONSTRAINT motherboards_pkey PRIMARY KEY (id);


--
-- Name: outputs outputs_pkey; Type: CONSTRAINT; Schema: public; Owner: testuser
--

ALTER TABLE ONLY public.outputs
    ADD CONSTRAINT outputs_pkey PRIMARY KEY (id);


--
-- Name: power_connector_connection_configurations power_connector_connection_configurations_pkey; Type: CONSTRAINT; Schema: public; Owner: testuser
--

ALTER TABLE ONLY public.power_connector_connection_configurations
    ADD CONSTRAINT power_connector_connection_configurations_pkey PRIMARY KEY (id);


--
-- Name: power_connectors power_connectors_pkey; Type: CONSTRAINT; Schema: public; Owner: testuser
--

ALTER TABLE ONLY public.power_connectors
    ADD CONSTRAINT power_connectors_pkey PRIMARY KEY (id);


--
-- Name: power_supplies power_supplies_pkey; Type: CONSTRAINT; Schema: public; Owner: testuser
--

ALTER TABLE ONLY public.power_supplies
    ADD CONSTRAINT power_supplies_pkey PRIMARY KEY (id);


--
-- Name: processors processors_pkey; Type: CONSTRAINT; Schema: public; Owner: testuser
--

ALTER TABLE ONLY public.processors
    ADD CONSTRAINT processors_pkey PRIMARY KEY (id);


--
-- Name: products products_pkey; Type: CONSTRAINT; Schema: public; Owner: testuser
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT products_pkey PRIMARY KEY (id);


--
-- Name: psu_adapters psu_adapters_pkey; Type: CONSTRAINT; Schema: public; Owner: testuser
--

ALTER TABLE ONLY public.psu_adapters
    ADD CONSTRAINT psu_adapters_pkey PRIMARY KEY (id);


--
-- Name: psu_power_connectors psu_power_connectors_pkey; Type: CONSTRAINT; Schema: public; Owner: testuser
--

ALTER TABLE ONLY public.psu_power_connectors
    ADD CONSTRAINT psu_power_connectors_pkey PRIMARY KEY (id);


--
-- Name: psu_series psu_series_pkey; Type: CONSTRAINT; Schema: public; Owner: testuser
--

ALTER TABLE ONLY public.psu_series
    ADD CONSTRAINT psu_series_pkey PRIMARY KEY (id);


--
-- Name: ram_memory_types ram_memory_types_pkey; Type: CONSTRAINT; Schema: public; Owner: testuser
--

ALTER TABLE ONLY public.ram_memory_types
    ADD CONSTRAINT ram_memory_types_pkey PRIMARY KEY (id);


--
-- Name: ram_series ram_series_pkey; Type: CONSTRAINT; Schema: public; Owner: testuser
--

ALTER TABLE ONLY public.ram_series
    ADD CONSTRAINT ram_series_pkey PRIMARY KEY (id);


--
-- Name: random_access_memory random_access_memory_pkey; Type: CONSTRAINT; Schema: public; Owner: testuser
--

ALTER TABLE ONLY public.random_access_memory
    ADD CONSTRAINT random_access_memory_pkey PRIMARY KEY (id);


--
-- Name: sockets sockets_pkey; Type: CONSTRAINT; Schema: public; Owner: testuser
--

ALTER TABLE ONLY public.sockets
    ADD CONSTRAINT sockets_pkey PRIMARY KEY (id);


--
-- Name: vendors vendors_pkey; Type: CONSTRAINT; Schema: public; Owner: testuser
--

ALTER TABLE ONLY public.vendors
    ADD CONSTRAINT vendors_pkey PRIMARY KEY (id);


--
-- PostgreSQL database dump complete
--

